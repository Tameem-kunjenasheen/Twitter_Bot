package com.rus.twitter.bot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TwitterBotApplicationTests {

	@Test
	void contextLoads() {
	}

}

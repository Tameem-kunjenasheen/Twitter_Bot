package com.rus.twitter.bot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TwitterBotApplication {
	public static void main(String[] args) {
		SpringApplication.run(TwitterBotApplication.class, args);
	}
}
